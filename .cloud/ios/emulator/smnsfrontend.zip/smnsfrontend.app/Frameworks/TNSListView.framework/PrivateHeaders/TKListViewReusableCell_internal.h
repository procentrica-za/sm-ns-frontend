//
//  TKListViewReusableCell.h
//  TelerikUI
//
//  Copyright (c) 2018 Telerik. All rights reserved.
//

@class TKListView;

@interface TKListViewReusableCell()

@property (nonatomic, weak) TKListView *ownerListView;

@end
