//
//  TKDataSourceGroup_Internal.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKDataSourceGroup.h"

@interface TKDataSourceGroup ()

@property (nonatomic, strong) id itemSource;

@end