//
//  TKRLVDataSource_Internal.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKRLVDataSource.h"

@interface TKRLVDataSource()

- (void)setDataSourceFor:(UIView*)view;

- (void)setDelegateFor:(UIView*)view;

@end
