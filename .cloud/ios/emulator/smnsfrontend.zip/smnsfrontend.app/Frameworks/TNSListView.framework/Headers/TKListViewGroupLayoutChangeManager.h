//
//  TKListViewGroupLayoutChangeManager.h
//  TelerikUI
//
//  Copyright © 2015 Telerik. All rights reserved.
//

#import "TKListViewLayoutChangeManager.h"

@interface TKListViewGroupLayoutChangeManager : TKListViewLayoutChangeManager

@property (nonatomic) BOOL isHeader;

@end
