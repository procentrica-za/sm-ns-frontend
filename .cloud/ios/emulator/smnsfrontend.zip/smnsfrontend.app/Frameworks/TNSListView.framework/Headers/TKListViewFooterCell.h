//
//  TKListViewFooterCell.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKListViewReusableCell.h"

/**
 A cell representing a group footer.
 */
@interface TKListViewFooterCell : TKListViewReusableCell

@end
