//
//  TKListViewStaggeredLayout.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKListViewGridLayout.h"

@class TKListViewStaggeredLayout;

@interface TKListViewStaggeredLayout : TKListViewGridLayout

@property (nonatomic) BOOL alignLastLine;

@end
