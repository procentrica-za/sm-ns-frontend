//
//  TKListViewGroupLayoutChange.h
//  TelerikUI
//
//  Copyright © 2015 Telerik. All rights reserved.
//

#import "TKListViewLayoutChange.h"

@interface TKListViewGroupLayoutChange : TKListViewLayoutChange

@property (nonatomic) BOOL isHeader;

@end
