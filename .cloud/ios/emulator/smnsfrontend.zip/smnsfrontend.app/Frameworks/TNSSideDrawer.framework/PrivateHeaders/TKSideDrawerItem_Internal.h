//
//  TKSideDrawerItem_Internal.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKSideDrawerItem.h"

@class TKStyleSheet;

@interface TKSideDrawerItem ()

@property (nonatomic, strong) TKStyleSheet *styleSheet;

@end
