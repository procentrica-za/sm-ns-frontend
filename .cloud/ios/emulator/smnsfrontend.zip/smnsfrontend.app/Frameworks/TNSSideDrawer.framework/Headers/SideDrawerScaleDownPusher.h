//
//  SideDrawerScaleDownPusher.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKSideDrawerTransition.h"

@interface SideDrawerScaleDownPusher : TKSideDrawerTransition

@property (nonatomic) CGSize scaleFactor;

@end
