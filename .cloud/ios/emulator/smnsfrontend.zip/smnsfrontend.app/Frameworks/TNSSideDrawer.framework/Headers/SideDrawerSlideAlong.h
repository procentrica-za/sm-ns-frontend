//
//  SideDrawerSlideAlong.h
//  TelerikUI
//
//  Copyright (c) 2014 Telerik. All rights reserved.
//

#import "SideDrawerReveal.h"

/**
 @discussion TKSideDrawer'sSlideAlong transition.
 */
@interface SideDrawerSlideAlong : SideDrawerReveal

@end
