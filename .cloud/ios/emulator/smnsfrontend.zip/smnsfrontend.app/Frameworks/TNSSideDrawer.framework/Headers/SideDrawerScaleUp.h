//
//  SideDrawerScaleUp.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKSideDrawerTransition.h"

/**
 @discussion TKSideDrawer's ScaleUp transition.
 */
@interface SideDrawerScaleUp : TKSideDrawerTransition

@end
