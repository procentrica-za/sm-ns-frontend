//
//  SideDrawerSlideInOnTop.h
//  TelerikUI
//
//  Copyright (c) 2014 Telerik. All rights reserved.
//

#import "TKSideDrawerTransition.h"

/**
 @discussion TKSideDrawer's SlideInOnTop transition.
 */
@interface SideDrawerSlideInOnTop : TKSideDrawerTransition

@end
