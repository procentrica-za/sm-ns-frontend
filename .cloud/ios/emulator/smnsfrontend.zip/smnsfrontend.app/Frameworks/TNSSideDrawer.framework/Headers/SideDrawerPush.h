//
//  SideDrawerPush.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKSideDrawerTransition.h"

@interface SideDrawerPush : TKSideDrawerTransition

@end
