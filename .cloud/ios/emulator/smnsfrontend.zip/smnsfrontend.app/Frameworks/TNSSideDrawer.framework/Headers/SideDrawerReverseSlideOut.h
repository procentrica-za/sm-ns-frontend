//
//  SideDrawerReverseSlideOut.h
//  TelerikUI
//
//  Copyright (c) 2014 Telerik. All rights reserved.
//

#import "SideDrawerReveal.h"

/**
 @discussion TKSideDrawer's ReverseSlideOut transition.
 */
@interface SideDrawerReverseSlideOut : SideDrawerReveal

@end
