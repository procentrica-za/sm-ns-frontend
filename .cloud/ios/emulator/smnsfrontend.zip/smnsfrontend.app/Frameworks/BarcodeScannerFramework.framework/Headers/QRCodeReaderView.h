#import <UIKit/UIKit.h>

/**
 * Overlay over the camera view to display the area (a square) where to scan the code.
 */
@interface QRCodeReaderView : UIView

@end
