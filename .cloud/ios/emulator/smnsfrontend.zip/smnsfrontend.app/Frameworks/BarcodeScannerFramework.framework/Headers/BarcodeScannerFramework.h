// In this header, you should import all the public headers of your framework using statements
#import "QRCodeReaderViewController.h"

//! Project version number for BarcodeScannerFramework.
FOUNDATION_EXPORT double BarcodeScannerFrameworkVersionNumber;

//! Project version string for BarcodeScannerFramework.
FOUNDATION_EXPORT const unsigned char BarcodeScannerFrameworkVersionString[];