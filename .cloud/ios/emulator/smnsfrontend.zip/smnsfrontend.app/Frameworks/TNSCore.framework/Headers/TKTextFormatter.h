//
//  TKTextFormatter.h
//  TelerikUI
//
//  Copyright © 2015 Telerik. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TKTextFormatter : NSObject

+ (NSString*)formatValue:(id)value withStringFormat:(NSString*)format;

@end
