//
//  TKCheckShape.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKShape.h"

@interface TKCheckShape : TKShape

@end
