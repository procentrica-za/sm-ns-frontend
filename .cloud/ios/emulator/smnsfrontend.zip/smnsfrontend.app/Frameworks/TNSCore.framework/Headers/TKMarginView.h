//
//  TKMarginView.h
//  TelerikUI
//

@protocol TKMarginView <NSObject>

/**
 View margins.
 */
@property (nonatomic) UIEdgeInsets margins;

@end
