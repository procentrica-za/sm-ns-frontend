require("./../../runtime.js");require("./../../vendor.js");module.exports =
(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["tns_modules/tns-core-modules/inspector_modules"],{

/***/ "./package.json":
/***/ (function(module) {

module.exports = {"main":"main.js","android":{"v8Flags":"--expose_gc","markingMode":"none"}};

/***/ })

},[["../node_modules/tns-core-modules/inspector_modules.js","runtime","vendor"]]]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0bnNfbW9kdWxlcy90bnMtY29yZS1tb2R1bGVzL2luc3BlY3Rvcl9tb2R1bGVzLmpzIiwic291cmNlUm9vdCI6IiJ9