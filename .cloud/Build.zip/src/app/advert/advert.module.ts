import { NgModule, NO_ERRORS_SCHEMA } from "@angular/core";
import { NativeScriptCommonModule } from 'nativescript-angular/common';
import { SharedModule } from "../shared/shared.module";
import { AdvertService } from "./advert.service";
import { AdvertHomeComponent } from "./advert-home/advert-home.component";
import { AdvertRoutingModule } from "./advert-routing.module";
import { NativeScriptUIListViewModule } from "nativescript-ui-listview/angular"
import { NgShadowModule} from "nativescript-ng-shadow";
import { AdvertDetailsComponent } from "./advert-details/advert-details.component";
import { MyAdvertComponent } from "./my-adverts/my-advert.component"
import { AddAdvertComponent } from "./add-advert/add-advert.component";
import { DropDownModule } from "nativescript-drop-down/angular";
import { NativeScriptFormsModule } from "nativescript-angular/forms";
import { ReactiveFormsModule } from "@angular/forms";
import { AdvertListPickerComponent } from "./advert-listpicker/advert-listpicker.component"
import { AdvertFilterComponent } from "./advert-filter-modal/advert-filter.component"
import { UpdateAdvertComponent } from "./update-advert/update-advert.component";
import { AdvertTextbookComponent } from "./advert-textbook/advert-textbook.component";
@NgModule({
    declarations: [
        AdvertHomeComponent,
        AdvertDetailsComponent,
        MyAdvertComponent,
        AddAdvertComponent,
        AdvertListPickerComponent,
        UpdateAdvertComponent,
        AdvertTextbookComponent,
        AdvertFilterComponent
    ],
    imports: [NativeScriptCommonModule,
              SharedModule,
              AdvertRoutingModule,
              NativeScriptUIListViewModule,
              NgShadowModule,
              DropDownModule,
              NativeScriptFormsModule,
              ReactiveFormsModule],
    providers: [
        AdvertService
    ],
    schemas: [NO_ERRORS_SCHEMA],
    entryComponents: [AdvertListPickerComponent, AdvertFilterComponent]
})

export class AdvertModule {}